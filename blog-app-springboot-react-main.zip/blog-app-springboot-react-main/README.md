# blog-app-springboot-react
It is a backend of blog application developed in spring boot and hibernate. Basically this project has the API's of blog app which are secured using spring security and it has JWT based authentication to role wise permit the users to access the API's.
