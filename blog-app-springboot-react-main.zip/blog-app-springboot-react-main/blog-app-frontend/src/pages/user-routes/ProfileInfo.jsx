import React from 'react'
import Base from '../../components/Base'

const ProfileInfo = () => {
  return (
    <Base>
      <div>ProfileInfo</div>
    </Base>
  )
}

export default ProfileInfo