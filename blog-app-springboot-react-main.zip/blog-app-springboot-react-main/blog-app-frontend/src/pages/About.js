import Base from "../components/Base";
import React from "react";

const About = () =>{
    return (
        <Base>



        </Base>
    );
}

export default About;